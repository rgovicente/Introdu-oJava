package com.senac.cadastro;

public class PessoaFisica implements PessoaFisicaJuridica{
    @Override
    public double calculoIR() {
        return 0;
    }
}
