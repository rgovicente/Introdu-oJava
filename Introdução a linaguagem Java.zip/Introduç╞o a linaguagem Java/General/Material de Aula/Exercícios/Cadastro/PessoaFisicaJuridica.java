package com.senac.cadastro;

public interface PessoaFisicaJuridica {
    public double calculoIR();
}
