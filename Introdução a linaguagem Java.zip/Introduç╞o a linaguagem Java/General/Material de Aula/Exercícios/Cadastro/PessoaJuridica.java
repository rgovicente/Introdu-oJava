package com.senac.cadastro;

public class PessoaJuridica implements PessoaFisicaJuridica{
    @Override
    public double calculoIR() {
        return 0;
    }
}
