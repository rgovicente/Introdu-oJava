package com.senac.zoologico;

public interface Animal {
    public void emitirSom();
    public void nascer();
}
