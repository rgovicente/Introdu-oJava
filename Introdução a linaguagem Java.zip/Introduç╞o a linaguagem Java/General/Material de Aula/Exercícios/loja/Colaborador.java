package com.senac.loja;

public interface Colaborador {
    public double calcularSalario();
}
