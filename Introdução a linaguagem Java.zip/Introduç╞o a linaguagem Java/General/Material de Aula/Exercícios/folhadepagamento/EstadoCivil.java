package com.senac.folhadepagamento;

public enum EstadoCivil {
    SOLTEIRO,CASADO,VIUVO,DIVORCIADO
}
