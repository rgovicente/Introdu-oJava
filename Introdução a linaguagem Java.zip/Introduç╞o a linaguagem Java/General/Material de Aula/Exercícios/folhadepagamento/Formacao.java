package com.senac.folhadepagamento;

public enum Formacao {
    MEDIO,SUPERIOR,POS,MESTRADO,DOUTORADO
}
