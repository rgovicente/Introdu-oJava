package com.senac.folhadepagamento;

public enum Estado {
    SP, RJ, MG
}
